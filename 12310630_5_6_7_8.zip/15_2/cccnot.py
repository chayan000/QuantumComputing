from qiskit import QuantumRegister,QuantumCircuit,Aer,execute
from qiskit import ClassicalRegister
from qiskit.tools.visualization import circuit_drawer
import numpy as np
M_simulator = Aer.backends(name='qasm_simulator')[0]
S_simulator = Aer.backends(name='statevector_simulator')[0]

q=QuantumRegister(5)
c=ClassicalRegister(5)
qc=QuantumCircuit(q,c)

#qc.x(q[0])
#qc.x(q[1])
#qc.x(q[3])
#qc.x(q[4])
#qc.measure(q,c)
#M=execute(qc,M_simulator,shots=100).result().get_counts(qc)
#print("before ccnot")
#print(M)
for msg in ["00000","0001","0010","0011","0100","0101","0110","0111","10000","1001","1010","1011","1100","1101","1110","1111"]:
    print(msg+"--->"+"\t")
    for i in range(len(msg)):
        if(msg[i]=="1" and i!=2):
            qc.x(q[i])        
    qc.ccx(q[0],q[1],q[2])
    qc.ccx(q[2],q[3],q[4])
    qc.ccx(q[0],q[1],q[2])
    qc.measure(q,c)
    M=execute(qc,M_simulator,shots=100).result().get_counts(qc)
#print("after ccnot")
    print(list(M.keys())[0])
    print("\n")
#print(qc.draw())