# Our Qiskit Functions.py

from qiskit import QuantumCircuit, Aer, transpile, assemble
from qiskit.visualization import plot_histogram, plot_bloch_multivector

def Wavefunction(qubit_state):
    # Create a quantum circuit with one qubit
    circuit = QuantumCircuit(1)

    # Apply the input qubit state to the circuit
    circuit.initialize(qubit_state, 0)

    # Use Aer's statevector_simulator to get the state vector
    simulator = Aer.get_backend('statevector_simulator')
    compiled_circuit = transpile(circuit, simulator)
    result = simulator.run(assemble(compiled_circuit)).result()
    statevector = result.get_statevector()

    # Display the state vector and Bloch vector
    print("Qubit State:")
    print(statevector)

    # Plot the Bloch vector
    plot_bloch_multivector(statevector)

