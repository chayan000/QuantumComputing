from qiskit import QuantumRegister,QuantumCircuit,Aer,execute, ClassicalRegister

S_simulator=Aer.backends(name='qasm_simulator')[0]
q=QuantumRegister(3)
c=ClassicalRegister(3)
qc=QuantumCircuit(q,c)
qc.x(q[0])
qc.h(q[1])
qc.id(q[2])
qc.measure(q,c)
job=execute(qc,S_simulator)
result=job.result()
M=result.get_counts(qc)
print(M)

